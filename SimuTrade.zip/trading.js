import { getSession, addContract, updateSessionBalance } from "./userSessions.js";

export const buyTrade = (ws, params) => {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      reject(new Error("Trade execution timeout"));
    }, 10000);

    const handleMessage = (msg) => {
      try {
        const data = JSON.parse(msg);

        if (data.buy) {
          clearTimeout(timeout);
          ws.removeListener("message", handleMessage);

          if (data.buy.contract_id) {
            resolve({
              contractId: data.buy.contract_id,
              payout: data.buy.payout,
              askPrice: data.buy.ask_price,
              status: "executed"
            });
          } else {
            reject(new Error(data.error?.message || "Trade failed"));
          }
        }

        if (data.error) {
          clearTimeout(timeout);
          ws.removeListener("message", handleMessage);
          reject(new Error(data.error.message));
        }
      } catch (error) {
        clearTimeout(timeout);
        ws.removeListener("message", handleMessage);
        reject(error);
      }
    };

    ws.on("message", handleMessage);

    // Send trade request
    ws.send(JSON.stringify({
      buy: 1,
      price: params.amount,
      parameters: {
        amount: params.amount,
        basis: "stake",
        contract_type: params.contractType || "CALL",
        currency: params.currency || "USD",
        duration: params.duration || 5,
        duration_unit: params.durationUnit || "t",
        symbol: params.symbol || "R_100"
      }
    }));
  });
};

export const sellTrade = (ws, contractId, price) => {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      reject(new Error("Sell execution timeout"));
    }, 10000);

    const handleMessage = (msg) => {
      try {
        const data = JSON.parse(msg);

        if (data.sell) {
          clearTimeout(timeout);
          ws.removeListener("message", handleMessage);
          resolve({
            contractId: data.sell.contract_id,
            transactionId: data.sell.transaction_id,
            status: "sold"
          });
        }

        if (data.error) {
          clearTimeout(timeout);
          ws.removeListener("message", handleMessage);
          reject(new Error(data.error.message));
        }
      } catch (error) {
        clearTimeout(timeout);
        ws.removeListener("message", handleMessage);
        reject(error);
      }
    };

    ws.on("message", handleMessage);

    ws.send(JSON.stringify({
      sell: contractId,
      price: price
    }));
  });
};