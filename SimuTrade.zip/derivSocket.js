import WebSocket from "ws";

const DERIV_URL = "wss://ws.derivws.com/websockets/v3?app_id=1089";

export const createDerivConnection = () => {
  const ws = new WebSocket(DERIV_URL);

  ws.on("open", () => {
    console.log("Connected to Deriv WebSocket");
  });

  ws.on("error", (error) => {
    console.error("WebSocket error:", error);
  });

  ws.on("close", () => {
    console.log("Disconnected from Deriv WebSocket");
  });

  return ws;
};

export const authorizeUser = (ws, token) => {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      reject(new Error("Authorization timeout"));
    }, 5000);

    const handleMessage = (msg) => {
      try {
        const data = JSON.parse(msg);

        if (data.msg_type === "authorize") {
          clearTimeout(timeout);
          ws.removeListener("message", handleMessage);

          if (data.authorize && data.authorize.loginid) {
            resolve({
              authorized: true,
              accountId: data.authorize.loginid,
              email: data.authorize.email,
              currency: data.authorize.currency
            });
          } else {
            reject(new Error(data.error?.message || "Authorization failed"));
          }
        }
      } catch (error) {
        clearTimeout(timeout);
        ws.removeListener("message", handleMessage);
        reject(error);
      }
    };

    ws.on("message", handleMessage);

    // Send authorization
    ws.send(JSON.stringify({ authorize: token }));
  });
};

export const getBalance = (ws) => {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      reject(new Error("Balance request timeout"));
    }, 5000);

    const handleMessage = (msg) => {
      try {
        const data = JSON.parse(msg);

        if (data.msg_type === "balance") {
          clearTimeout(timeout);
          ws.removeListener("message", handleMessage);
          resolve(data.balance);
        }
      } catch (error) {
        clearTimeout(timeout);
        ws.removeListener("message", handleMessage);
        reject(error);
      }
    };

    ws.on("message", handleMessage);
    ws.send(JSON.stringify({ balance: 1 }));
  });
};