import express from "express";
import cors from "cors";
import { createDerivConnection, authorizeUser, getBalance } from "./derivSocket.js";
import {
  createSession,
  getSession,
  deleteSession,
  updateSessionBalance,
  addContract,
  getContracts,
  getAllSessions,
  getSessionCount
} from "./userSessions.js";
import { buyTrade, sellTrade } from "./trading.js";
import {
  subscribeToContract,
  unsubscribeFromContract,
  getContractStatus,
  getAllSubscriptions,
  unsubscribeAllContracts
} from "./tradeManager.js";
import {
  createWebSocketServer,
  sendToUser,
  broadcastToAll,
  sendContractUpdate,
  sendContractUpdateToUser,
  getClientCount,
  getSubscriptionCount,
  getActiveUsers
} from "./websocketServer.js";
import {
  registerContract,
  getUserForContract,
  unregisterContract,
  unregisterUserContracts
} from "./contractManager.js";

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3000;
const WS_PORT = process.env.WS_PORT || 3001;

// Initialize WebSocket server for frontend
createWebSocketServer(WS_PORT);
console.log(`WebSocket server running on port ${WS_PORT}`);

// Main Deriv connection
const derivWs = createDerivConnection();

// Handle Deriv contract updates and forward to frontend
derivWs.on("message", (msg) => {
  try {
    const data = JSON.parse(msg);

    // Forward proposal_open_contract updates (contract price/status changes)
    if (data.proposal_open_contract) {
      const update = data.proposal_open_contract;
      const contractId = update.contract_id;
      
      // Get user for this contract
      const userId = getUserForContract(contractId);
      
      if (userId) {
        console.log(`Forwarding update for contract ${contractId} to user ${userId}`);
        
        // Send to user and contract subscribers
        sendContractUpdateToUser(userId, contractId, update);
      } else {
        // Still send to contract subscribers if any
        sendContractUpdate(contractId, update);
      }
    }

    // Forward balance updates
    if (data.balance) {
      console.log(`Balance update: ${data.balance.balance}`);
      // Balance updates can be sent to all active sessions if needed
    }

    // Forward buy responses
    if (data.buy) {
      const { contract_id } = data.buy;
      console.log(`Trade bought: ${contract_id}`);
    }

    // Forward sell responses
    if (data.sell) {
      const { contract_id } = data.sell;
      console.log(`Trade sold: ${contract_id}`);
    }
  } catch (error) {
    console.error("Error processing Deriv message:", error);
  }
});

// Cleanup inactive sessions every 30 minutes
setInterval(() => {
  const sessions = getAllSessions();
  const now = Date.now();
  const maxInactiveTime = 1 * 60 * 60 * 1000;

  sessions.forEach(session => {
    if (now - session.lastActivity > maxInactiveTime) {
      unregisterUserContracts(session.userId);
      unsubscribeAllContracts(session.userId);
      deleteSession(session.userId);
      console.log(`Session cleanup: Deleted inactive session for ${session.userId}`);
    }
  });
}, 30 * 60 * 1000);

// Routes

app.get("/", (req, res) => {
  res.json({ status: "Backend running ✅" });
});

app.post("/connect", async (req, res) => {
  try {
    const { userId, token } = req.body;

    if (!userId || !token) {
      return res.status(400).json({ 
        error: "userId and token are required" 
      });
    }

    const existingSession = getSession(userId);
    if (existingSession) {
      return res.status(400).json({ 
        error: "User already has an active session" 
      });
    }

    const ws = createDerivConnection();

    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error("Connection timeout")), 5000);
      ws.on("open", () => {
        clearTimeout(timeout);
        resolve();
      });
      ws.on("error", reject);
    });

    const accountInfo = await authorizeUser(ws, token);
    const balance = await getBalance(ws);
    
    const session = createSession(userId, token, ws, accountInfo);
    updateSessionBalance(userId, balance);

    // Setup Deriv message handler for this user's connection
    ws.on("message", (msg) => {
      try {
        const data = JSON.parse(msg);

        if (data.msg_type === "balance") {
          updateSessionBalance(userId, data.balance);
          
          // Send balance update to frontend
          sendToUser(userId, {
            type: "balance_update",
            balance: data.balance,
            timestamp: Date.now()
          });
        }

        if (data.proposal_open_contract) {
          const contract = data.proposal_open_contract;
          
          // Update session contract
          const sessionContract = session.contracts.find(c => c.contractId === contract.contract_id);
          if (sessionContract) {
            sessionContract.currentSpot = contract.current_spot;
            sessionContract.profit = contract.profit;
            sessionContract.profitPercentage = contract.profit_percentage;
            sessionContract.status = contract.status;
            sessionContract.isExpired = contract.is_expired;
            sessionContract.isWin = contract.is_win;
            sessionContract.lastUpdate = Date.now();
          }
        }
      } catch (error) {
        console.error("Error processing user connection message:", error);
      }
    });

    // Notify frontend of successful connection
    sendToUser(userId, {
      type: "connected",
      accountId: accountInfo.accountId,
      email: accountInfo.email,
      currency: accountInfo.currency,
      balance
    });

    res.json({
      status: "connected",
      accountId: accountInfo.accountId,
      email: accountInfo.email,
      currency: accountInfo.currency,
      balance,
      wsPort: WS_PORT
    });
  } catch (error) {
    console.error("Connection error:", error);
    res.status(401).json({ 
      error: error.message || "Authorization failed" 
    });
  }
});

app.post("/buy", async (req, res) => {
  try {
    const { userId, amount, contractType = "CALL", duration = 5, symbol = "R_100" } = req.body;

    if (!userId || !amount) {
      return res.status(400).json({ 
        error: "userId and amount are required" 
      });
    }

    if (amount <= 0) {
      return res.status(400).json({ 
        error: "amount must be greater than 0" 
      });
    }

    const session = getSession(userId);
    if (!session) {
      return res.status(404).json({ 
        error: "Session not found" 
      });
    }

    if (!session.ws || session.ws.readyState !== 1) {
      return res.status(500).json({ 
        error: "WebSocket connection lost" 
      });
    }

    if (session.balance < amount) {
      return res.status(400).json({ 
        error: `Insufficient balance. Available: ${session.balance}, Required: ${amount}` 
      });
    }

    const result = await buyTrade(session.ws, {
      amount,
      contractType,
      duration,
      symbol,
      currency: session.currency
    });

    const contractId = result.contractId;

    // Register contract with user
    registerContract(contractId, userId);

    addContract(userId, {
      contractId,
      type: "buy",
      amount,
      payout: result.payout,
      askPrice: result.askPrice,
      createdAt: Date.now(),
      status: "active",
      profit: 0,
      profitPercentage: 0
    });

    // Subscribe to contract updates on Deriv
    await subscribeToContract(session.ws, contractId, userId);

    updateSessionBalance(userId, session.balance - amount);

    // Push trade execution to frontend
    sendToUser(userId, {
      type: "trade_executed",
      contractId,
      tradeType: "buy",
      amount,
      payout: result.payout,
      askPrice: result.askPrice,
      newBalance: session.balance - amount,
      timestamp: Date.now()
    });

    res.json({
      status: "success",
      contractId,
      payout: result.payout,
      askPrice: result.askPrice,
      newBalance: session.balance - amount
    });
  } catch (error) {
    console.error("Buy trade error:", error);
    
    sendToUser(req.body.userId, {
      type: "trade_error",
      error: error.message,
      timestamp: Date.now()
    });

    res.status(400).json({ 
      error: error.message || "Trade execution failed" 
    });
  }
});

app.post("/sell", async (req, res) => {
  try {
    const { userId, contractId, price } = req.body;

    if (!userId || !contractId || price === undefined) {
      return res.status(400).json({ 
        error: "userId, contractId, and price are required" 
      });
    }

    const session = getSession(userId);
    if (!session) {
      return res.status(404).json({ 
        error: "Session not found" 
      });
    }

    if (!session.ws || session.ws.readyState !== 1) {
      return res.status(500).json({ 
        error: "WebSocket connection lost" 
      });
    }

    const contract = session.contracts.find(c => c.contractId === contractId);
    if (!contract) {
      return res.status(404).json({ 
        error: "Contract not found" 
      });
    }

    const result = await sellTrade(session.ws, contractId, price);

    contract.status = "sold";
    contract.sellPrice = price;
    contract.soldAt = Date.now();

    const profit = price - contract.amount;
    updateSessionBalance(userId, session.balance + profit);

    // Unregister contract
    unregisterContract(contractId);

    // Push sell to frontend
    sendToUser(userId, {
      type: "trade_sold",
      contractId,
      sellPrice: price,
      profit,
      newBalance: session.balance + profit,
      timestamp: Date.now()
    });

    res.json({
      status: "success",
      contractId,
      price,
      profit,
      newBalance: session.balance + profit
    });
  } catch (error) {
    console.error("Sell trade error:", error);
    res.status(400).json({ 
      error: error.message || "Sell execution failed" 
    });
  }
});

app.get("/contracts/:userId", (req, res) => {
  const contracts = getContracts(req.params.userId);
  res.json({ contracts });
});

app.get("/session/:userId", (req, res) => {
  const session = getSession(req.params.userId);

  if (!session) {
    return res.status(404).json({ error: "Session not found" });
  }

  res.json({
    userId: session.userId,
    accountId: session.accountId,
    email: session.email,
    currency: session.currency,
    balance: session.balance,
    contractCount: session.contracts.length,
    createdAt: session.createdAt,
    lastActivity: session.lastActivity
  });
});

app.delete("/disconnect/:userId", (req, res) => {
  unregisterUserContracts(req.params.userId);
  unsubscribeAllContracts(req.params.userId);
  deleteSession(req.params.userId);

  sendToUser(req.params.userId, {
    type: "disconnected",
    message: "Session ended",
    timestamp: Date.now()
  });

  res.json({ status: "disconnected" });
});

app.get("/stats", (req, res) => {
  res.json({
    server: {
      expressPort: PORT,
      wsPort: WS_PORT
    },
    sessions: {
      active: getSessionCount(),
      users: getAllSessions().map(s => s.userId)
    },
    websocket: {
      connectedClients: getClientCount(),
      activeUsers: getActiveUsers(),
      activeSubscriptions: getSubscriptionCount()
    },
    details: getAllSessions().map(s => ({
      userId: s.userId,
      accountId: s.accountId,
      balance: s.balance,
      contracts: s.contracts.length
    }))
  });
});

app.listen(PORT, () => {
  console.log(`Express server running on port ${PORT}`);
});