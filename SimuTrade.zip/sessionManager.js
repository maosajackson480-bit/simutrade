const sessions = new Map();

/**
 * Create a new user session
 * @param {string} userId - Unique user identifier
 * @param {string} token - Deriv API token
 * @param {WebSocket} ws - WebSocket connection to Deriv
 */
export const createSession = (userId, token, ws) => {
  const session = {
    userId,
    token,
    ws,
    contracts: [],
    createdAt: Date.now(),
    lastActivity: Date.now(),
    balance: null,
    accountId: null
  };
  
  sessions.set(userId, session);
  console.log(`Session created for user: ${userId}`);
  
  return session;
};

/**
 * Get an existing session
 */
export const getSession = (userId) => {
  const session = sessions.get(userId);
  if (session) {
    session.lastActivity = Date.now();
  }
  return session;
};

/**
 * Delete a session
 */
export const deleteSession = (userId) => {
  const session = sessions.get(userId);
  if (session) {
    // Close WebSocket if still open
    if (session.ws && session.ws.readyState === 1) {
      session.ws.close();
    }
    sessions.delete(userId);
    console.log(`Session deleted for user: ${userId}`);
    return true;
  }
  return false;
};

/**
 * Update balance for a session
 */
export const updateSessionBalance = (userId, balance) => {
  const session = getSession(userId);
  if (session) {
    session.balance = balance;
    return session;
  }
  return null;
};

/**
 * Add a contract to user's session
 */
export const addContract = (userId, contract) => {
  const session = getSession(userId);
  if (session) {
    session.contracts.push({
      ...contract,
      addedAt: Date.now()
    });
    return session.contracts;
  }
  return null;
};

/**
 * Get all contracts for a user
 */
export const getContracts = (userId) => {
  const session = getSession(userId);
  return session ? session.contracts : [];
};

/**
 * Remove a contract from user's session
 */
export const removeContract = (userId, contractId) => {
  const session = getSession(userId);
  if (session) {
    session.contracts = session.contracts.filter(c => c.id !== contractId);
    return true;
  }
  return false;
};

/**
 * Get all active sessions
 */
export const getAllSessions = () => {
  return Array.from(sessions.values());
};

/**
 * Clear inactive sessions (older than maxAge milliseconds)
 */
export const clearInactiveSessions = (maxAge = 3600000) => { // 1 hour default
  const now = Date.now();
  const toDelete = [];
  
  for (const [userId, session] of sessions.entries()) {
    if (now - session.lastActivity > maxAge) {
      toDelete.push(userId);
    }
  }
  
  toDelete.forEach(userId => deleteSession(userId));
  
  if (toDelete.length > 0) {
    console.log(`Cleared ${toDelete.length} inactive sessions`);
  }
  
  return toDelete.length;
};

/**
 * Get session count
 */
export const getSessionCount = () => sessions.size;