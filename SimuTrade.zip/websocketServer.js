import { WebSocketServer } from "ws";
import { getUserForContract } from "./contractManager.js";

// Store client connections by userId
const clients = new Map();

// Store subscription mappings: contractId → Set<clients>
const contractSubscriptions = new Map();

export const createWebSocketServer = (port = 3001) => {
  const wss = new WebSocketServer({ port });

  wss.on("connection", (client) => {
    console.log("Frontend client connected");

    let clientUserId = null;

    client.on("message", (msg) => {
      try {
        const data = JSON.parse(msg);

        if (data.type === "register") {
          // Client registers with userId
          clientUserId = data.userId;
          
          // Store mapping
          if (clients.has(clientUserId)) {
            clients.get(clientUserId).push(client);
          } else {
            clients.set(clientUserId, [client]);
          }

          console.log(`User ${clientUserId} registered for real-time updates`);

          // Send confirmation
          client.send(JSON.stringify({
            type: "registered",
            userId: clientUserId,
            message: "Connected to real-time updates"
          }));
        }

        if (data.type === "subscribe") {
          const { contractId } = data;
          
          if (!contractSubscriptions.has(contractId)) {
            contractSubscriptions.set(contractId, new Set());
          }
          contractSubscriptions.get(contractId).add(client);

          client.send(JSON.stringify({
            type: "subscribed",
            contractId,
            message: `Subscribed to contract ${contractId}`
          }));
        }

        if (data.type === "unsubscribe") {
          const { contractId } = data;
          
          if (contractSubscriptions.has(contractId)) {
            contractSubscriptions.get(contractId).delete(client);
            
            if (contractSubscriptions.get(contractId).size === 0) {
              contractSubscriptions.delete(contractId);
            }
          }

          client.send(JSON.stringify({
            type: "unsubscribed",
            contractId
          }));
        }

        if (data.type === "ping") {
          client.send(JSON.stringify({
            type: "pong",
            timestamp: Date.now()
          }));
        }
      } catch (error) {
        console.error("Error processing WebSocket message:", error);
      }
    });

    client.on("close", () => {
      if (clientUserId) {
        const userClients = clients.get(clientUserId);
        if (userClients) {
          const index = userClients.indexOf(client);
          if (index > -1) {
            userClients.splice(index, 1);
          }
          
          if (userClients.length === 0) {
            clients.delete(clientUserId);
            console.log(`User ${clientUserId} disconnected`);
          }
        }
      }

      // Remove from all contract subscriptions
      for (const [contractId, clientSet] of contractSubscriptions.entries()) {
        clientSet.delete(client);
        if (clientSet.size === 0) {
          contractSubscriptions.delete(contractId);
        }
      }
    });

    client.on("error", (error) => {
      console.error("WebSocket error:", error);
    });
  });

  return wss;
};

/**
 * Send update to specific user
 */
export const sendToUser = (userId, data) => {
  const userClients = clients.get(userId);
  
  if (userClients && userClients.length > 0) {
    const message = JSON.stringify(data);
    userClients.forEach(client => {
      if (client.readyState === 1) {
        client.send(message);
      }
    });
    return true;
  }
  return false;
};

/**
 * Send update to all users
 */
export const broadcastToAll = (data) => {
  const message = JSON.stringify(data);
  
  for (const userClients of clients.values()) {
    userClients.forEach(client => {
      if (client.readyState === 1) {
        client.send(message);
      }
    });
  }
};

/**
 * Send contract update to all subscribers
 */
export const sendContractUpdate = (contractId, update) => {
  const contractClients = contractSubscriptions.get(contractId);
  
  if (contractClients && contractClients.size > 0) {
    const message = JSON.stringify({
      type: "trade_update",
      contractId,
      data: {
        contract_id: contractId,
        current_spot: update.current_spot,
        current_spot_time: update.current_spot_time,
        current_spot_display_value: update.current_spot_display_value,
        profit: update.profit,
        profit_percentage: update.profit_percentage,
        payout: update.payout,
        sell_price: update.sell_price,
        status: update.status,
        is_expired: update.is_expired,
        is_win: update.is_win,
        entry_spot: update.entry_spot,
        entry_spot_time: update.entry_spot_time,
        expiry_time: update.expiry_time,
        purchase_time: update.purchase_time,
        strike_price: update.strike_price,
        underlying: update.underlying,
        contract_type: update.contract_type,
        duration: update.duration,
        duration_type: update.duration_type
      },
      timestamp: Date.now()
    });

    contractClients.forEach(client => {
      if (client.readyState === 1) {
        client.send(message);
      }
    });
    return true;
  }
  return false;
};

/**
 * Send contract update to user and their subscribers
 */
export const sendContractUpdateToUser = (userId, contractId, update) => {
  // Send to user
  sendToUser(userId, {
    type: "contract_update",
    contractId,
    data: update,
    timestamp: Date.now()
  });

  // Send to contract subscribers
  sendContractUpdate(contractId, update);
};

/**
 * Get active clients count
 */
export const getClientCount = () => {
  let count = 0;
  for (const userClients of clients.values()) {
    count += userClients.length;
  }
  return count;
};

/**
 * Get subscription count
 */
export const getSubscriptionCount = () => contractSubscriptions.size;

/**
 * Get active users
 */
export const getActiveUsers = () => clients.size;