// Configuration
const API_URL = "http://localhost:3000"; // Backend REST API
const WS_URL = "ws://localhost:3001"; // WebSocket server

// State
let socket = null;
let userId = null;
let connected = false;
let trades = new Map(); // contractId → trade data
let stats = {
  totalProfit: 0,
  winCount: 0,
  lossCount: 0,
  totalTrades: 0
};

// Initialize
document.addEventListener("DOMContentLoaded", () => {
  setupWebSocket();
});

// Setup WebSocket connection
function setupWebSocket() {
  socket = new WebSocket(WS_URL);

  socket.onopen = () => {
    console.log("✅ WebSocket connected");
    updateWSStatus(true);
  };

  socket.onmessage = (event) => {
    const data = JSON.parse(event.data);
    handleMessage(data);
  };

  socket.onerror = (error) => {
    console.error("❌ WebSocket error:", error);
    updateWSStatus(false);
    showAlert("WebSocket connection error", "error");
  };

  socket.onclose = () => {
    console.log("❌ WebSocket disconnected");
    updateWSStatus(false);
    connected = false;
    updateConnectionStatus();
  };
}

// Handle WebSocket messages
function handleMessage(data) {
  const { type } = data;

  switch (type) {
    case "registered":
      console.log("✅ Registered:", data);
      showAlert(`Connected as ${data.userId}`, "success");
      break;

    case "connected":
      handleConnected(data);
      break;

    case "disconnected":
      handleDisconnected(data);
      break;

    case "balance_update":
      updateBalance(data.balance);
      break;

    case "trade_executed":
      handleTradeExecuted(data);
      break;

    case "trade_sold":
      handleTradeSold(data);
      break;

    case "trade_update":
      handleTradeUpdate(data);
      break;

    case "trade_error":
      showAlert(`Trade Error: ${data.error}`, "error");
      break;

    case "contract_update":
      handleContractUpdate(data);
      break;

    default:
      console.log("Unknown message type:", type, data);
  }
}

// Connect to backend
async function connect() {
  const userIdInput = document.getElementById("userId").value;
  const tokenInput = document.getElementById("apiToken").value;

  if (!userIdInput || !tokenInput) {
    showAlert("Please enter User ID and API Token", "error");
    return;
  }

  userId = userIdInput;

  try {
    const response = await fetch(`${API_URL}/connect`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId: userIdInput,
        token: tokenInput
      })
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.error);
    }

    connected = true;
    updateConnectionStatus();

    // Register with WebSocket
    socket.send(JSON.stringify({
      type: "register",
      userId: userIdInput
    }));

    showAlert("✅ Connected to Deriv!", "success");
    document.getElementById("connectBtn").disabled = true;
    document.getElementById("disconnectBtn").disabled = false;
    document.getElementById("buyBtn").disabled = false;
  } catch (error) {
    showAlert(`Connection failed: ${error.message}`, "error");
  }
}

// Disconnect
async function disconnect() {
  if (!userId) return;

  try {
    await fetch(`${API_URL}/disconnect/${userId}`, { method: "DELETE" });
    connected = false;
    userId = null;
    trades.clear();
    stats = { totalProfit: 0, winCount: 0, lossCount: 0, totalTrades: 0 };
    updateConnectionStatus();
    updateTradesList();
    updateStats();

    document.getElementById("connectBtn").disabled = false;
    document.getElementById("disconnectBtn").disabled = true;
    document.getElementById("buyBtn").disabled = true;

    showAlert("Disconnected", "info");
  } catch (error) {
    showAlert(`Disconnect failed: ${error.message}`, "error");
  }
}

// Buy trade
async function buyTrade() {
  if (!connected || !userId) {
    showAlert("Not connected", "error");
    return;
  }

  const amount = parseFloat(document.getElementById("stakeAmount").value);
  const contractType = document.getElementById("contractType").value;
  const duration = parseInt(document.getElementById("duration").value);
  const symbol = document.getElementById("symbol").value;

  if (!amount || amount <= 0) {
    showAlert("Invalid stake amount", "error");
    return;
  }

  try {
    document.getElementById("buyBtn").disabled = true;

    const response = await fetch(`${API_URL}/buy`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId,
        amount,
        contractType,
        duration,
        symbol
      })
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.error);
    }

    showAlert(`✅ Trade executed! Contract ID: ${result.contractId}`, "success");

    // Subscribe to contract updates
    socket.send(JSON.stringify({
      type: "subscribe",
      contractId: result.contractId
    }));
  } catch (error) {
    showAlert(`Buy failed: ${error.message}`, "error");
  } finally {
    document.getElementById("buyBtn").disabled = false;
  }
}

// Sell trade
async function sellTrade(contractId) {
  if (!connected || !userId) {
    showAlert("Not connected", "error");
    return;
  }

  const trade = trades.get(contractId);
  if (!trade) {
    showAlert("Trade not found", "error");
    return;
  }

  try {
    const response = await fetch(`${API_URL}/sell`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId,
        contractId,
        price: trade.currentSpot || trade.profit
      })
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.error);
    }

    showAlert(`✅ Trade closed! Profit: $${result.profit.toFixed(2)}`, "success");
  } catch (error) {
    showAlert(`Sell failed: ${error.message}`, "error");
  }
}

// Handle connected message
function handleConnected(data) {
  document.getElementById("accountId").textContent = data.accountId;
  document.getElementById("currency").textContent = data.currency;
  updateBalance(data.balance);
}

// Handle disconnected message
function handleDisconnected(data) {
  connected = false;
  updateConnectionStatus();
  showAlert(data.message, "info");
}

// Update balance display
function updateBalance(balance) {
  document.getElementById("balanceDisplay").textContent = `$${parseFloat(balance).toFixed(2)}`;
}

// Handle trade executed
function handleTradeExecuted(data) {
  const { contractId, tradeType, amount, newBalance } = data;

  trades.set(contractId, {
    contractId,
    type: tradeType,
    amount,
    status: "active",
    profit: 0,
    profitPercentage: 0,
    createdAt: Date.now(),
    currentSpot: 0
  });

  updateBalance(newBalance);
  updateTradesList();
  document.getElementById("tradeCount").textContent = trades.size;
}

// Handle trade sold
function handleTradeSold(data) {
  const { contractId, profit } = data;

  const trade = trades.get(contractId);
  if (trade) {
    trade.status = "sold";
    trade.profit = profit;

    stats.totalProfit += profit;
    stats.totalTrades++;

    if (profit > 0) {
      stats.winCount++;
    } else if (profit < 0) {
      stats.lossCount++;
    }
  }

  updateTradesList();
  updateStats();
  setTimeout(() => trades.delete(contractId), 2000);
}

// Handle trade update
function handleTradeUpdate(data) {
  const { contractId, data: contractData } = data;

  let trade = trades.get(contractId);
  if (!trade) {
    trade = { contractId, status: "active", createdAt: Date.now() };
    trades.set(contractId, trade);
  }

  trade.currentSpot = contractData.current_spot;
  trade.profit = contractData.profit;
  trade.profitPercentage = contractData.profit_percentage;
  trade.isExpired = contractData.is_expired;
  trade.isWin = contractData.is_win;

  if (contractData.is_expired) {
    trade.status = contractData.is_win ? "won" : "lost";

    if (contractData.is_win) {
      stats.winCount++;
    } else {
      stats.lossCount++;
    }
    stats.totalTrades++;
  }

  updateTradesList();
  updateStats();
}

// Handle contract update
function handleContractUpdate(data) {
  handleTradeUpdate(data);
}

// Update trades list UI
function updateTradesList() {
  const tradesList = document.getElementById("tradesList");

  if (trades.size === 0) {
    tradesList.innerHTML = '<p style="color: #999; grid-column: 1 / -1;">No active trades</p>';
    return;
  }

  tradesList.innerHTML = Array.from(trades.values()).map(trade => `
    <div class="trade-card">
      <div class="trade-header">
        <span class="trade-id">${trade.contractId.substring(0, 8)}...</span>
        <span class="trade-status ${trade.status}">${trade.status.toUpperCase()}</span>
      </div>
      <div class="trade-info">
        <strong>${trade.type} Trade</strong><br>
        Stake: $${trade.amount.toFixed(2)}<br>
        Current Spot: ${trade.currentSpot ? trade.currentSpot.toFixed(4) : '-'}
      </div>
      <div class="trade-profit ${trade.profit > 0 ? 'positive' : trade.profit < 0 ? 'negative' : 'zero'}">
        P&L: $${trade.profit.toFixed(2)} (${trade.profitPercentage.toFixed(2)}%)
      </div>
      ${trade.status === 'active' ? `
        <div class="trade-actions">
          <button class="btn-success" onclick="sellTrade('${trade.contractId}')">Sell</button>
        </div>
      ` : ''}
    </div>
  `).join('');
}

// Update stats
function updateStats() {
  document.getElementById("totalProfit").textContent = `$${stats.totalProfit.toFixed(2)}`;
  document.getElementById("winCount").textContent = stats.winCount;
  document.getElementById("lossCount").textContent = stats.lossCount;

  const winRate = stats.totalTrades > 0 
    ? ((stats.winCount / stats.totalTrades) * 100).toFixed(1)
    : 0;
  document.getElementById("winRate").textContent = `${winRate}%`;
}

// Update connection status UI
function updateConnectionStatus() {
  const badge = document.getElementById("connectionStatus");
  if (connected) {
    badge.classList.remove("disconnected");
    badge.classList.add("connected");
    badge.innerHTML = '<div class="dot"></div><span>Connected</span>';
  } else {
    badge.classList.remove("connected");
    badge.classList.add("disconnected");
    badge.innerHTML = '<div class="dot"></div><span>Disconnected</span>';
  }
}

// Update WebSocket status UI
function updateWSStatus(status) {
  const badge = document.getElementById("wsStatus");
  if (status) {
    badge.classList.remove("disconnected");
    badge.classList.add("connected");
    badge.innerHTML = '<div class="dot"></div><span>WebSocket: Online</span>';
  } else {
    badge.classList.remove("connected");
    badge.classList.add("disconnected");
    badge.innerHTML = '<div class="dot"></div><span>WebSocket: Offline</span>';
  }
}

// Show alert
function showAlert(message, type = "info") {
  const alert = document.getElementById("alert");
  alert.textContent = message;
  alert.className = `alert alert-${type} show`;
  setTimeout(() => alert.classList.remove("show"), 5000);
}