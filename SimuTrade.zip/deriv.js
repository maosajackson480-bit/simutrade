import WebSocket from "ws";

const DERIV_URL = "wss://ws.derivws.com/websockets/v3?app_id=1089";

export const createDerivConnection = (apiToken) => {
  const ws = new WebSocket(DERIV_URL);
  let balanceData = null;

  ws.on("open", () => {
    console.log("Connected to Deriv");
    
    // Authorize with API token
    ws.send(JSON.stringify({
      authorize: apiToken
    }));
  });

  ws.on("message", (msg) => {
    try {
      const data = JSON.parse(msg.data || msg);
      
      if (data.msg_type === "authorize") {
        console.log("Authorization successful");
        // Request balance after successful authorization
        ws.send(JSON.stringify({ balance: 1 }));
      }
      
      if (data.msg_type === "balance") {
        balanceData = data.balance;
        console.log("Balance updated:", balanceData);
      }
    } catch (error) {
      console.error("Error parsing Deriv message:", error);
    }
  });

  ws.on("error", (error) => {
    console.error("WebSocket error:", error);
  });

  ws.on("close", () => {
    console.log("Disconnected from Deriv");
  });

  // Return both the connection and a getter for balance data
  return {
    connection: ws,
    getBalance: () => balanceData,
    sendMessage: (msg) => ws.send(JSON.stringify(msg))
  };
};