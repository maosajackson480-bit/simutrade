// Map contract_id → userId
const contractToUser = new Map();

// Map userId → contract_ids
const userContracts = new Map();

/**
 * Register a contract with a user
 */
export const registerContract = (contractId, userId) => {
  contractToUser.set(contractId, userId);
  
  if (!userContracts.has(userId)) {
    userContracts.set(userId, new Set());
  }
  userContracts.get(userId).add(contractId);
};

/**
 * Get userId for a contract
 */
export const getUserForContract = (contractId) => {
  return contractToUser.get(contractId);
};

/**
 * Get all contracts for a user
 */
export const getContractsForUser = (userId) => {
  return userContracts.get(userId) || new Set();
};

/**
 * Unregister a contract
 */
export const unregisterContract = (contractId) => {
  const userId = contractToUser.get(contractId);
  if (userId) {
    const userSet = userContracts.get(userId);
    if (userSet) {
      userSet.delete(contractId);
    }
    contractToUser.delete(contractId);
  }
};

/**
 * Unregister all contracts for a user
 */
export const unregisterUserContracts = (userId) => {
  const contracts = userContracts.get(userId);
  if (contracts) {
    contracts.forEach(contractId => {
      contractToUser.delete(contractId);
    });
    userContracts.delete(userId);
  }
};