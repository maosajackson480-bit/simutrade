const sessions = new Map();

export const createSession = (userId, token, ws, accountInfo) => {
  const session = {
    userId,
    token,
    ws,
    accountId: accountInfo.accountId,
    email: accountInfo.email,
    currency: accountInfo.currency,
    balance: null,
    contracts: [],
    createdAt: Date.now(),
    lastActivity: Date.now()
  };

  sessions.set(userId, session);
  console.log(`Session created for user: ${userId}`);

  return session;
};

export const getSession = (userId) => {
  const session = sessions.get(userId);
  if (session) {
    session.lastActivity = Date.now();
  }
  return session;
};

export const updateSessionBalance = (userId, balance) => {
  const session = getSession(userId);
  if (session) {
    session.balance = balance;
  }
  return session;
};

export const deleteSession = (userId) => {
  const session = sessions.get(userId);
  if (session && session.ws) {
    session.ws.close();
  }
  return sessions.delete(userId);
};

export const addContract = (userId, contract) => {
  const session = getSession(userId);
  if (session) {
    session.contracts.push(contract);
  }
  return session?.contracts;
};

export const getContracts = (userId) => {
  const session = getSession(userId);
  return session?.contracts || [];
};

export const getAllSessions = () => Array.from(sessions.values());

export const getSessionCount = () => sessions.size;