import { getSession, addContract } from "./userSessions.js";

// Track active subscriptions
const subscriptions = new Map();

export const subscribeToContract = (ws, contractId, userId) => {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      reject(new Error("Subscription timeout"));
    }, 5000);

    const handleMessage = (msg) => {
      try {
        const data = JSON.parse(msg);

        if (data.proposal_open_contract && data.proposal_open_contract.contract_id === contractId) {
          clearTimeout(timeout);

          if (!subscriptions.has(contractId)) {
            subscriptions.set(contractId, {
              contractId,
              userId,
              subscribedAt: Date.now(),
              updates: []
            });
          }

          ws.removeListener("message", handleMessage);
          
          resolve({
            contractId,
            status: "subscribed",
            contract: data.proposal_open_contract
          });
        }
      } catch (error) {
        clearTimeout(timeout);
        ws.removeListener("message", handleMessage);
        reject(error);
      }
    };

    ws.on("message", handleMessage);

    ws.send(JSON.stringify({
      proposal_open_contract: 1,
      contract_id: contractId,
      subscribe: 1
    }));
  });
};

export const unsubscribeFromContract = (ws, contractId) => {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      reject(new Error("Unsubscribe timeout"));
    }, 5000);

    const handleMessage = (msg) => {
      try {
        const data = JSON.parse(msg);

        if (data.proposal_open_contract && data.proposal_open_contract.contract_id === contractId) {
          clearTimeout(timeout);
          ws.removeListener("message", handleMessage);
          subscriptions.delete(contractId);
          
          resolve({
            contractId,
            status: "unsubscribed"
          });
        }
      } catch (error) {
        clearTimeout(timeout);
        ws.removeListener("message", handleMessage);
        reject(error);
      }
    };

    ws.on("message", handleMessage);

    ws.send(JSON.stringify({
      proposal_open_contract: 1,
      contract_id: contractId,
      subscribe: 0
    }));
  });
};

export const setupContractUpdates = (ws, userId) => {
  ws.on("message", (msg) => {
    try {
      const data = JSON.parse(msg);

      if (data.proposal_open_contract) {
        const contract = data.proposal_open_contract;
        const subscription = subscriptions.get(contract.contract_id);

        if (subscription) {
          // Store update
          subscription.updates.push({
            timestamp: Date.now(),
            currentSpot: contract.current_spot,
            currentSpotTime: contract.current_spot_time,
            currentSpotDisplayValue: contract.current_spot_display_value,
            status: contract.status,
            profit: contract.profit,
            profitPercentage: contract.profit_percentage,
            buyPrice: contract.buy_price,
            sellPrice: contract.sell_price,
            sellTime: contract.sell_time,
            isWin: contract.is_win,
            isExpired: contract.is_expired
          });

          // Update session contract
          const session = getSession(userId);
          if (session) {
            const sessionContract = session.contracts.find(c => c.contractId === contract.contract_id);
            if (sessionContract) {
              sessionContract.currentSpot = contract.current_spot;
              sessionContract.profit = contract.profit;
              sessionContract.profitPercentage = contract.profit_percentage;
              sessionContract.status = contract.status;
              sessionContract.isExpired = contract.is_expired;
              sessionContract.isWin = contract.is_win;
              sessionContract.lastUpdate = Date.now();
            }
          }
        }
      }
    } catch (error) {
      console.error("Error processing contract update:", error);
    }
  });
};

export const getContractUpdates = (contractId) => {
  const subscription = subscriptions.get(contractId);
  return subscription ? subscription.updates : [];
};

export const getContractStatus = (contractId) => {
  const subscription = subscriptions.get(contractId);
  if (!subscription || subscription.updates.length === 0) {
    return null;
  }

  const latestUpdate = subscription.updates[subscription.updates.length - 1];
  return latestUpdate;
};

export const getAllSubscriptions = () => {
  return Array.from(subscriptions.entries()).map(([contractId, sub]) => ({
    contractId,
    userId: sub.userId,
    subscribedAt: sub.subscribedAt,
    updateCount: sub.updates.length,
    lastUpdate: sub.updates.length > 0 ? sub.updates[sub.updates.length - 1] : null
  }));
};

export const unsubscribeAllContracts = (userId) => {
  const userContracts = Array.from(subscriptions.entries())
    .filter(([, sub]) => sub.userId === userId)
    .map(([contractId]) => contractId);

  userContracts.forEach(contractId => {
    subscriptions.delete(contractId);
  });

  return userContracts;
};